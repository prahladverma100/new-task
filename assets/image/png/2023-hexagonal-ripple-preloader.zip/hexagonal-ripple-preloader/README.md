# Hexagonal Ripple Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/ExNJRee](https://codepen.io/jkantner/pen/ExNJRee).

A hexagon-like preloader based on a [GIF by CONCINNUS](https://twitter.com/concinnus/status/1359124907699888128).